#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\Users\Rayhan\flutter_windows_3.47.5-stable\flutter"
export "FLUTTER_APPLICATION_PATH=C:\Users\Rayhan\OneDrive\Documents\GLOBAL INSTITUT\SEMESTER 5\APLIKASI MOBILE\UTS\uts_pml_1126180062\soal2_profil_app"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=C:\Users\Rayhan\OneDrive\Documents\GLOBAL INSTITUT\SEMESTER 5\APLIKASI MOBILE\UTS\uts_pml_1126180062\soal2_profil_app\macos\Flutter\ephemeral\Packages\.packages\FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
